# CLAUDE.md

Notes for whichever AI assistant (Claude Code, Cursor, etc.) is working in this repo.

## Stack

- Runtime: Node.js (LTS)
- Language: [e.g. TypeScript]
- Package manager: npm
- Framework: [fill in once decided — e.g. Express, Next.js]

## Commit conventions

I'm using Conventional Commits. Format:

```
<type>(<scope>): <short description>
```

Types I use most: `feat`, `fix`, `docs`, `chore`, `refactor`, `test`.

Examples:
- `feat(auth): add login form`
- `fix(api): handle empty response from server`
- `docs: update setup instructions`

Keep commits small and focused on one change. Don't bundle unrelated edits.

## Code style

- 2-space indentation
- Prefer straightforward, readable code over clever one-liners
- Add a comment when the "why" isn't obvious from the code itself

## Working with me

- Ask before adding a new dependency — I'd rather know why it's needed
- If you're not sure which approach I want, ask instead of guessing
- Point out mistakes or bad ideas directly, don't just go along with what I ask if there's a better way
