#!/bin/bash
# Run this from inside your new project folder, after copying in
# README.md, LICENSE, .gitignore, and CLAUDE.md.
#
# Usage: bash setup-repo.sh <your-github-repo-url>

set -e

if [ -z "$1" ]; then
  echo "Usage: bash setup-repo.sh https://github.com/<you>/<repo>.git"
  exit 1
fi

REPO_URL=$1

git init
git branch -M main

git add README.md
git commit -m "docs: add initial README stub"

git add LICENSE .gitignore
git commit -m "chore: add license and gitignore"

git add CLAUDE.md
git commit -m "docs: add CLAUDE.md with stack and conventions"

git remote add origin "$REPO_URL"
git push -u origin main

echo ""
echo "Done. Three commits made and pushed to $REPO_URL"
echo "Next: open Claude Code or Cursor, ask it to review README.md,"
echo "apply one improvement, then commit with:"
echo '  git commit -am "docs: clarify setup instructions per AI review"'
