# [Project Name]

A capstone project built as part of my AI-assisted development track. This is early-stage — I'm using it to practice working with an AI coding assistant (Claude Code / Cursor) as a real part of my dev workflow, not just for one-off snippets.

## What this is

[One or two sentences: what does this project actually do, and why did you pick it? e.g. "A small habit tracker that helps me log daily routines and see streaks over time. I picked it because it's simple enough to finish but has enough moving parts (auth, storage, a UI) to be a real test of the workflow."]

## Stack

- **Language:** [e.g. TypeScript]
- **Runtime:** Node.js (LTS)
- **Framework:** [e.g. Express / Next.js / none yet]
- **Package manager:** npm

## Getting started

```bash
git clone https://github.com/<your-username>/<repo-name>.git
cd <repo-name>
npm install
```

Nothing to run yet — this is just the scaffolding. More to come as the project develops.

## Project conventions

See `CLAUDE.md` for how I'm working with my AI assistant on this repo, including commit style and code conventions.

## Status

🚧 Just getting started. Basic repo structure is in place; first real features are next.
